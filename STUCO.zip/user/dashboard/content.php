<div class="jumbotron text-center">
<h1>Welcome <?php echo $userRow['name'] ?></h1>
</div>